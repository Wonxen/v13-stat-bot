# Wonxen Stat Bot

Öncelikle herkese merhaba 👋. Hazırlamış olduğum bu stat botu projesini paylaşıyorum. İndirip dilediğiniz gibi kullanabilirsiniz. Projeyi her hangi bir ücretli satım veya kendi yapmış gibi gösterme durumunda gerekli işlemler başlatılacaktır.

### Kurulum Aşamaları:

- [🛠 Gerekenler](#-gerekenler)
- [📩 Kurulum](#-kurulum)
- [🙏 Teşekkürler](#-teşekkürler)

#### 🛠 Gerekenler

İlk olarak botu kuracağınız Windows işletim sisteminde [Node.JS](https://nodejs.org/en/) kurulu olmalı. Son sürümü kurmanızda fayda var.anızda fayda var.

#### 📩 Kurulum

- İlk olarak projeyi kuracağınız sisteme indirin.
- Daha sonra klasöre girip Shift + Sağ Tık yapıp oradan PowerShell penceresini buradan açın seçeneğine tıklayıp PowerShell penceresini açın.
- npm i Komutunu kullanarak gerekli modülleri indirin ve indirme işleminin bitmesini bekleyin.

#### 🙏 Teşekkürler

Projemi kullanıp bana destek olan herkese teşekkür ederim. Bana [**Mail Göndererek**](mailto:emreecanbaltaa@icloud.com) ulaşabilirsiniz.

 <details>
    <summary align="center"> &nbsp; &nbsp; &nbsp; <b>Görseller</b></summary>
    <p align="center">
     <img src="https://cdn.discordapp.com/attachments/828589873253449838/936245529938108456/unknown.png">
     <img src="https://cdn.discordapp.com/attachments/828589873253449838/936245681675468820/unknown.png">
     <img src="https://cdn.discordapp.com/attachments/828589873253449838/936245759123271750/unknown.png">
  </p>
  </details>
  

